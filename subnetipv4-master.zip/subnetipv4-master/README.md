# Subnetting IPv4

IPv4 Subnetting Quiz for practice.

## Installation (XAMPP)
Just extract to htdocs folder.

## Usage
Access the url. Ex: `http://localhost/subnet`

##
Assembled by [Deny](https://id.linkedin.com/in/deny-ramdhany-b75828125).
